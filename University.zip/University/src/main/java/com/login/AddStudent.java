package com.login;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Servlet implementation class AddStudent
 */
public class AddStudent extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		String marks = request.getParameter("marks");
		String status = request.getParameter("status");
		String password = request.getParameter("password");
		//int i=0;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college", "root", "asdf@1234");
			PreparedStatement pst = con
					.prepareStatement("Insert into students(name,email,address,marks,status,password)values(?,?,?,?,?,?)");
			pst.setString(1, name);
			pst.setString(2, email);
			pst.setString(3, address);
			pst.setString(4, marks);
			pst.setString(5, status);
			pst.setString(6, password);
			System.out.println("query submitted"+ pst);

			int i = pst.executeUpdate();
			pst.close();
			con.close();
			if (i>0) {
				response.sendRedirect("Dashboard.jsp");
			}else {
				out.println("Invalid details");
				out.println("Please try After sometime");
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
