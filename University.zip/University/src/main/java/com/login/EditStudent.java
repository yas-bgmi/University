package com.login;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class EditStudent extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		
		
	}

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String name = request.getParameter("name");
		String status = request.getParameter("status");
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college", "root", "asdf@1234");
			
			// Fetch the id of the student using the name or any other unique attribute
			PreparedStatement pst1 = con.prepareStatement("select id from students where name=?");
			pst1.setString(1, name);
			ResultSet rs = pst1.executeQuery();
			int id = 0;
			if(rs.next()) {
				id = rs.getInt("id");
			}
			pst1.close();
			
			// Update the student's details using the fetched id
			PreparedStatement pst = con
					.prepareStatement("update students set status=? where id=?");
			
			//pst.setString(1, name);
			pst.setString(1, status);
			pst.setInt(2, id);
			
			System.out.println("query submitted"+ pst);

			int i = pst.executeUpdate();
			pst.close();
			con.close();
			if (i>0) {
				out.println("Record Updated");
				response.sendRedirect("Dashboard.jsp");
			}else {
				out.println("Invalid details");
				out.println("Please try After sometime");
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			response.sendRedirect("login.jsp");
		} catch (SQLException e) {
			e.printStackTrace();
			response.sendRedirect("login.jsp");
		}
	}
}
