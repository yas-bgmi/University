package com.login;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			response.setContentType("text/html");
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college", "root", "asdf@1234");
			String query = "Select * from students";
			PreparedStatement ps=con.prepareStatement(query);
			ResultSet srs=ps.executeQuery();
			PrintWriter sout=response.getWriter();
			sout.print("<html><body><table border='1'><tr><td>id</td><td>name</td><td>email</td><td>address</td><td>marks</td><td>status</td></tr>");
			while(srs.next()) {
				sout.println("<tr><td>"+srs.getString(1)+"</td>"
						+ "<td>"+srs.getString(2)+"</td>"
						+ "<td>"+srs.getString(3)+"</td>"
						+ "<td>"+srs.getString(4)+"</td>"
						+ "<td>"+srs.getString(5)+"</td>"
						+ "<td>"+srs.getString(6)+"</td></tr>");
			}
			sout.println("</table></body></html>");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (SQLException e) {
		e.printStackTrace();
	}

}
}
