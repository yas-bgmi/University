package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public Login() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		PrintWriter out = response.getWriter();
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String role = request.getParameter("role");
System.out.println("radio matched"+ role);
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String query=null;
		if(role.equals("Student")) {
			query = "Select * from students where email = ? AND password = ?";
		}else if(role.equals("Teacher")) {
			query="Select * from teachers where email = ? AND password = ?";
		}else if(role.equals("Admin")) {
			query="Select * from admin where email = ? AND password = ?";
		}else {
			out.print("<h1>" + email + ": Please enter correct Logins</h1><br>");
			out.print("<h1>" + password + ": Login Failed</h1><br>");
			response.sendRedirect("login.jsp");
		}
		//String query = "Select * from students where email = ? AND password = ?";
		//String query1 = "Select * from teachers where email = ? AND password = ?";
		//String query2 = "Select * from admin where email = ? AND password = ?";
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college", "root", "asdf@1234");
				PreparedStatement pstmt = con.prepareStatement(query);) {
			
			pstmt.setString(1, email);
			pstmt.setString(2, password);
			try (ResultSet rs = pstmt.executeQuery();) {
				if (rs.next()) {
					response.setHeader("Cache-Control","no-cache, no-store, must revalidate");	
					
					HttpSession session = request.getSession();
					session.setAttribute("id", rs.getInt(1));
					session.setAttribute("name", rs.getString(2));
					session.setAttribute("email", rs.getString(3));
					session.setAttribute("password", rs.getString(7));
					response.sendRedirect("Dashboard.jsp?role"+role);
				} else {
					out.print("<h1>" + email + ": Please enter correct Logins</h1><br>");
					out.print("<h1>" + password + ": Login Failed</h1><br>");
					response.sendRedirect("login.jsp");
				}
			}
		} catch (SQLException e) {
			out.print("<h1>: Login Faild !! beacuse of SQL exception</h1><br>");
			e.printStackTrace();
		}
	}

	/*
	 * protected void doPost(HttpServletRequest request, HttpServletResponse
	 * response) throws ServletException, IOException { doGet(request, response); }
	 */
}