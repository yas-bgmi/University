package com.login;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class TestServlet
 */
public class TestServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public TestServlet() {
		super();
	}
     
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		//response.setHeader("Cache-Control","no-cache, no-store, must revalidate");
		// System.out.println("id >>>>" + session.getAttribute("id"));
		// System.out.println("name >>>>" + session.getAttribute("name"));
		// System.out.println("email >>>>" + session.getAttribute("email"));
		// System.out.println("password >>>>" + session.getAttribute("password"));

		PrintWriter out = response.getWriter();
		out.print("<h3 style = 'color:green'> User Login succesfully</h3>");
		out.print("<h1 style = 'color:green'>Welcome !!" + session.getAttribute("name") + "</h1>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}