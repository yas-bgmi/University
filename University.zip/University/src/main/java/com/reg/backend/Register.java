package com.reg.backend;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
@WebServlet("/regForm")
public class Register extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		
		PrintWriter out = resp.getWriter();
		out.println();
		
		String myemail = req.getParameter("email1");
		String myname = req.getParameter("name1");
		String mypassword = req.getParameter("password1");
		
		
		 try {
			 	//DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college","root","asdf@1234");
	            
	            
	            PreparedStatement ps = con.prepareStatement("insert into register (email,name,password) values(?,?,?)");
	            ps.setString(1, myemail);
	            ps.setString(2, myname);
	            ps.setString(3, mypassword);
	            
	            int count = ps.executeUpdate();
	            if (count>0) {
	            	
	            	resp.setContentType("text/html");
	            	out.print("<h3 style = 'color:green'> User register succesfully</h3>");
	            	
	            	RequestDispatcher rd = req.getRequestDispatcher("/register.html");
	            	rd.include(req,resp);
	            	
	            }
	            else {
	            	resp.setContentType("text/html");
	            	out.print("<h3 style = 'color:red'> User is register invalid logins</h3>");
	            	
	            	RequestDispatcher rd = req.getRequestDispatcher("/register.html");
	            	rd.include(req,resp);
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	            
	            resp.setContentType("text/html");
            	out.print("<h3 style = 'color:red'> Exception Occured:"+e.getMessage()+" User not register succesfully</h3>");
            	
            	RequestDispatcher rd = req.getRequestDispatcher("/register.html");
            	rd.include(req,resp);
            	
	        }
	}
	
}
