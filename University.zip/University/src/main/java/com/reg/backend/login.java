package com.reg.backend;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@SuppressWarnings("serial")
@WebServlet("/loginForm")
public class login extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		
		PrintWriter out = resp.getWriter();
		out.println("h1");
		
		String myemail = req.getParameter("email1");
		String mypassword = req.getParameter("password1");
		
		/*
		 * if(myemail== "") { out.println("email is required"); }
		 * 
		 * if(mypassword== ""){ out.println("password is required"); } System. exit(0);
		 * 
		 */
		
		
		 try {
			 	//DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
	            Class.forName("com.mysql.cj.jdbc.Driver");	
	            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college","root","asdf@1234");
	            
	            
	            PreparedStatement ps = con.prepareStatement("select * from students where email=? and password = ?");
	            ps.setString(1, myemail);
	            ps.setString(2, mypassword);
	            
	            ResultSet rs = ps.executeQuery();
	            if (rs.next()) {
	            	//store session
	            	HttpSession session = req.getSession();
	            	session.setAttribute("id", rs.getInt(1));
	            	session.setAttribute("name", rs.getString(2));
	            	session.setAttribute("email", rs.getString(3));
	            	session.setAttribute("password", rs.getString(7));
	            	
	            	resp.setContentType("text/html");
	            	out.print("<h3 style = 'color:green'> User Login succesfully</h3>");
	            	
	            	RequestDispatcher rd = req.getRequestDispatcher("/test.jsp");
	            	rd.include(req,resp);
	            	
	            }
	            else {
	            	resp.setContentType("text/html");
	            	out.print("<h3 style = 'color:red'> User is register invalid logins</h3>");
	            	
	            	RequestDispatcher rd = req.getRequestDispatcher("/login.html");
	            	rd.include(req,resp);
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	            
	            resp.setContentType("text/html");
            	out.print("<h3 style = 'color:red'> Exception Occured:"+e.getMessage()+" User not register succesfully</h3>");
            	
            	RequestDispatcher rd = req.getRequestDispatcher("/login.html");
            	rd.include(req,resp);
            	
	        }
	}
	
}
