package com.college.Database.Teacher;

import java.util.Scanner;
import com.college.Database.ActiveDataFromDatabase;
import com.college.Database.DeleteDataFromDatabase;
import com.college.Database.DisplayDataFromDatabase;
import com.college.Database.InactiveDataFromDatabase;
import com.college.Database.InsertDataIntoDatabase;
import com.college.Database.MenuMethod;
import com.college.Database.UpdateDataIntoDatabase;
import com.college.Database.Student.StudentMethod;

/**
 * This is Teacher Method and it will use when we call request from CRUD
 * operations
 */

public class TeacherMethod {
	StudentMethod studentMethod = new StudentMethod();
	MenuMethod menuMethod = new MenuMethod();

	Scanner sc = new Scanner(System.in);

	public String Teacher() {
		System.out.println("1. All Teachers\n" + "2. Insert Teachers\n" + "3. Update Teachers\n"
				+ "4. Delete Students\n" + "5. Active Status\n" + "6. Inactive Status\n" + "7. Main Menu");
		System.out.println("Enter Choice: ");
		InsertDataIntoDatabase ind = new InsertDataIntoDatabase();
		DeleteDataFromDatabase del = new DeleteDataFromDatabase();
		DisplayDataFromDatabase disp = new DisplayDataFromDatabase();
		UpdateDataIntoDatabase upd = new UpdateDataIntoDatabase();
		ActiveDataFromDatabase actdb = new ActiveDataFromDatabase();
		InactiveDataFromDatabase inactdb = new InactiveDataFromDatabase();

		int teacher = sc.nextInt();
		if (teacher == 1) {
			System.out.println("All Teachers");
			disp.displayData("Teacher");
			Teacher();
		} else if (teacher == 2) {
			System.out.println("Insert New Teacher Name");
			ind.insertData("Teacher");
			Teacher();
		} else if (teacher == 3) {
			System.out.println("Update Existing User");
			upd.updateData("Teacher");
			Teacher();
		} else if (teacher == 4) {
			System.out.println("Delete Data");
			del.deleteData("Teacher");
			Teacher();
		} else if (teacher == 5) {
			System.out.println("Active Status");
			actdb.activeCollegeData("Teacher");
			Teacher();
		} else if (teacher == 6) {
			System.out.println("Inactive Status");
			inactdb.inactiveData("Teacher");
			Teacher();
		} else {
			menuMethod.menu();
		}

		return Teacher();

	}
}
