package com.college.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import com.college.Database.Dbconnection.DbConnection;


/**
 * This file is used for getting Inactive Data which is stored value 0  ;;;;;
 */

public class InactiveDataFromDatabase {
	Scanner sc = new Scanner(System.in);
	MenuMethod menuMethod = new MenuMethod();
	
	public void inactiveData(String typeOfInactiveData) {
		if(typeOfInactiveData.equalsIgnoreCase("Student")) {                             
			/**
			 *  // Students Inactive Data  ########
			 */
		try {
			Connection con = DbConnection.getConnect();
			PreparedStatement pst = con.prepareStatement("Select * from Students where status = 0");
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|"
						+ rs.getInt(4));
			}
			menuMethod.menu();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error Found");
		}
		}else if(typeOfInactiveData.equalsIgnoreCase("Teacher")) {                              
			/**
			 *  // Teachers Inactive Data  ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from Teachers where status = 0");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|"
							+ rs.getInt(4) + "|" + rs.getInt(5));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}
			
		}else if(typeOfInactiveData.equalsIgnoreCase("Cource")) {                              
			/**
			 *  // Courses Inactive Data  ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from Cources where status = 0");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|"
							+ rs.getInt(4) + "|" + rs.getString(5));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}
			
		}else if(typeOfInactiveData.equalsIgnoreCase("Department")) {                          
			/**
			 *  // Department Inactive Data  ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from Department where status = 0");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|"
							+ rs.getInt(4) + "|" + rs.getDate(5));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}
			
		}else if(typeOfInactiveData.equalsIgnoreCase("Admin")) {                             
			/**
			 *  // Admin Inactive Data  ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from admin where status = 0");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|"
							+ rs.getInt(4) + "|" + rs.getDate(5));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

			
		}else if(typeOfInactiveData.equalsIgnoreCase("Liberary")) {                               
			/**
			 *  // Library Inactive Data  ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from liberary where status = 0");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|"
							+ rs.getInt(4) + "|" + rs.getString(5) + "|" + rs.getInt(6));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}
			
		}else if(typeOfInactiveData.equalsIgnoreCase("Sport")) {                               
			/**
			 *  // Sports Inactive Data  ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from Sports where status = 0");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|"
							+ rs.getInt(4) + "|" + rs.getString(5) + "|" + rs.getInt(6));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

			
		}
	}


	
}
