package com.college.Database.Library;

import java.util.Scanner;

import com.college.Database.ActiveDataFromDatabase;
import com.college.Database.DeleteDataFromDatabase;
import com.college.Database.DisplayDataFromDatabase;
import com.college.Database.InactiveDataFromDatabase;
import com.college.Database.InsertDataIntoDatabase;
import com.college.Database.MenuMethod;
import com.college.Database.UpdateDataIntoDatabase;

/**
 * This is Library Method and it will use when we call request from CRUD
 * operations
 */

public class LiberaryMethod {
	Scanner sc = new Scanner(System.in);
	MenuMethod menuMethod = new MenuMethod();

	public String Liberary() {
		System.out.println("1. All Liberary\n" + "2. Insert Liberary\n" + "3. Update Liberary\n"
				+ "4. Delete Students\n" + "5. Active Status\n" + "6. Inactive Status\n" + "7. Main Menu");
		System.out.println("Enter Choice: ");
		InsertDataIntoDatabase ind = new InsertDataIntoDatabase();
		DeleteDataFromDatabase del = new DeleteDataFromDatabase();
		DisplayDataFromDatabase disp = new DisplayDataFromDatabase();
		UpdateDataIntoDatabase upd = new UpdateDataIntoDatabase();
		ActiveDataFromDatabase actdb = new ActiveDataFromDatabase();
		InactiveDataFromDatabase inactdb = new InactiveDataFromDatabase();

		int std = sc.nextInt();
		if (std == 1) {
			System.out.println("All Liberary");
			disp.displayData("Liberary");
			Liberary();
		} else if (std == 2) {
			System.out.println("Insert New Liberary Name");
			ind.insertData("Liberary");
			Liberary();
		} else if (std == 3) {
			System.out.println("Update Existing User");
			upd.updateData("Liberary");
			Liberary();
		} else if (std == 4) {
			System.out.println("Delete Data");
			del.deleteData("Liberary");
			Liberary();
		} else if (std == 5) {
			System.out.println("Active Status");
			actdb.activeCollegeData("Liberary");
			Liberary();
		} else if (std == 6) {
			System.out.println("Inactive Status");
			inactdb.inactiveData("Liberary");
			Liberary();
		} else {
			menuMethod.menu();
		}

		// sc.close();
		return null;
	}

}
