package com.college.Database.Admins;

/**
 * This file is an Admin main class which has stored getter & setter for Admin
 * operations;;;;
 */

public class Admin {

	private int id;
	private String name;
	private String streamName;
	private int addmissionId;
	private String addmissionDate;
	private int status;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStreamName() {
		return streamName;
	}

	public void setStreamName(String streamName) {
		this.streamName = streamName;
	}

	public int getAddmissionId() {
		return addmissionId;
	}

	public void setAddmissionId(int addmissionId) {
		this.addmissionId = addmissionId;
	}

	public String getAddmissionDate() {
		return addmissionDate;
	}

	public void setAddmissionDate(String addmissionDate) {
		this.addmissionDate = addmissionDate;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Admin [id=" + id + ", name=" + name + ", streamName=" + streamName + ", addmissionId=" + addmissionId
				+ ", addmissionDate=" + addmissionDate + ", status=" + status + ", getId()=" + getId() + ", getName()="
				+ getName() + ", getStreamName()=" + getStreamName() + ", getAddmissionId()=" + getAddmissionId()
				+ ", getAddmissionDate()=" + getAddmissionDate() + ", getStatus()=" + getStatus() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
