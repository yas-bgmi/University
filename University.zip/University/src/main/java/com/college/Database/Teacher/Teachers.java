	package com.college.Database.Teacher;

/**
 * This file is an Teachers main class which has stored getter & setter for
 * Teachers operations;;;;
 */

public class Teachers {

	private int id;
	private String name;
	private String teacherName;
	private int stdId;
	private int status;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public int getStdId() {
		return stdId;
	}

	public void setStdId(int stdId) {
		this.stdId = stdId;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Teachers [id=" + id + ", name=" + name + ", teacherName=" + teacherName + ", stdId=" + stdId
				+ ", status=" + status + ", getId()=" + getId() + ", getName()=" + getName() + ", getTeacherName()="
				+ getTeacherName() + ", getStdId()=" + getStdId() + ", getStatus()=" + getStatus() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
