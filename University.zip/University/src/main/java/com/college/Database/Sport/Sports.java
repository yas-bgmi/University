package com.college.Database.Sport;

/**
 * This file is an Sports main class which has stored getter & setter for Sports
 * operations;;;;
 */

public class Sports {

	private int id;
	private String name;
	private String streamName;
	private int sportsId;
	private String sportsName;
	private int status;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStreamName() {
		return streamName;
	}

	public void setStreamName(String streamName) {
		this.streamName = streamName;
	}

	public int getSportsId() {
		return sportsId;
	}

	public void setSportsId(int sportsId) {
		this.sportsId = sportsId;
	}

	public String getSportsName() {
		return sportsName;
	}

	public void setSportsName(String sportsName) {
		this.sportsName = sportsName;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Sports [id=" + id + ", name=" + name + ", streamName=" + streamName + ", sportsId=" + sportsId
				+ ", sportsName=" + sportsName + ", status=" + status + ", getId()=" + getId() + ", getName()="
				+ getName() + ", getStreamName()=" + getStreamName() + ", getSportsId()=" + getSportsId()
				+ ", getSportsName()=" + getSportsName() + ", getStatus()=" + getStatus() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
}