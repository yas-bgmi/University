package com.college.Database.Admins;

import java.util.Scanner;

import com.college.Database.ActiveDataFromDatabase;
import com.college.Database.DeleteDataFromDatabase;
import com.college.Database.DisplayDataFromDatabase;
import com.college.Database.InactiveDataFromDatabase;
import com.college.Database.InsertDataIntoDatabase;
import com.college.Database.MenuMethod;
import com.college.Database.UpdateDataIntoDatabase;

/**
 * This is Admin Method and it will use when we call request from CRUD
 * operations
 */

public class AdminMethod {
	Scanner sc = new Scanner(System.in);
	MenuMethod menuMethod = new MenuMethod();

	public String Admin() {

		System.out.println("1. All Admin \n" + "2. Insert Admin \n" + "3. Update Admin \n" + "4. Delete Students\n"
				+ "5. Active Status\n" + "6. Inactive Status\n" + "7. Main Menu");
		System.out.println("Enter Choice: ");
		InsertDataIntoDatabase ind = new InsertDataIntoDatabase();
		DeleteDataFromDatabase del = new DeleteDataFromDatabase();
		DisplayDataFromDatabase disp = new DisplayDataFromDatabase();
		UpdateDataIntoDatabase upd = new UpdateDataIntoDatabase();
		ActiveDataFromDatabase actdb = new ActiveDataFromDatabase();
		InactiveDataFromDatabase inactdb = new InactiveDataFromDatabase();

		int admin = sc.nextInt();
		if (admin == 1) {
			System.out.println("All Admins");
			disp.displayData("Admin");
			Admin();
		} else if (admin == 2) {
			System.out.println("Insert New Admin Name");
			ind.insertData("Admin");
			Admin();
		} else if (admin == 3) {
			System.out.println("Update Existing User");
			upd.updateData("Admin");
			Admin();
		} else if (admin == 4) {
			System.out.println("Delete Data");
			del.deleteData("Admin");
			Admin();
		} else if (admin == 5) {
			System.out.println("Active Status");
			actdb.activeCollegeData("Admin");
			Admin();
		} else if (admin == 6) {
			System.out.println("Inactive Status");
			inactdb.inactiveData("Admin");
			Admin();
		} else {
			menuMethod.menu();
		}

		// sc.close();
		return null;

	}

}
