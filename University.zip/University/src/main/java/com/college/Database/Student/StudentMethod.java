package com.college.Database.Student;

import java.util.Scanner;

import com.college.Database.ActiveDataFromDatabase;
import com.college.Database.DeleteDataFromDatabase;
import com.college.Database.DisplayDataFromDatabase;
import com.college.Database.InactiveDataFromDatabase;
import com.college.Database.InsertDataIntoDatabase;
import com.college.Database.MenuMethod;
import com.college.Database.UpdateDataIntoDatabase;

/**
 * This is Students Method and it will use when we call request from CRUD
 * operations
 */

public class StudentMethod {

	Scanner sc = new Scanner(System.in);
	MenuMethod menuMethod = new MenuMethod();

	public String Student() {
		System.out.println("1. All Students\n" + "2. Insert Student\n" + "3. Update Student\n" + "4. Delete Students\n"
				+ "5. Active Status\n" + "6. Inactive Status\n" + "7. Main Menu");
		System.out.println("Enter Choice: ");
		
		  InsertDataIntoDatabase ind = new InsertDataIntoDatabase();
		  DeleteDataFromDatabase del = new DeleteDataFromDatabase();
		  DisplayDataFromDatabase disp = new DisplayDataFromDatabase();
		  UpdateDataIntoDatabase upd = new UpdateDataIntoDatabase();
		  ActiveDataFromDatabase actdb = new ActiveDataFromDatabase();
		  InactiveDataFromDatabase inactdb = new InactiveDataFromDatabase();
		 

		int std = sc.nextInt();
		if (std == 1) {
			System.out.println("All Students");
			disp.displayData("Student");
			Student();
		} else if (std == 2) {
			System.out.println("Insert New Student Name");
			ind.insertData("Student");
			Student();
		} else if (std == 3) {
			System.out.println("Update Existing User");
			upd.updateData("Student");
			Student();
		} else if (std == 4) {
			System.out.println("Delete Student data");
			del.deleteData("Student");
			Student();
		} else if (std == 5) {
			System.out.println("active Status");
			actdb.activeCollegeData("Student");
			Student();
		} else if (std == 6) {
			System.out.println("Inactive Status");
			inactdb.inactiveData("Student");
			Student();
		} else {
			menuMethod.menu();
		}

		sc.close();
		return null;
	}
}
