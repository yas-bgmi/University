package com.college.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import com.college.Database.Dbconnection.DbConnection;

/**
 * This file is used for Display data which is includes Active Data & Inactive
 * Data whose stored in DataBase ;;;;;
 */

public class DisplayDataFromDatabase {
	MenuMethod menuMethod = new MenuMethod(); // Menu Method
	Scanner sc = new Scanner(System.in);

	public void displayData(String typeOfDisplay) {
		if (typeOfDisplay.equalsIgnoreCase("Student")) {
			/**
			 * // Students Display Data ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from students");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out
							.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|" + rs.getInt(4));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfDisplay.equalsIgnoreCase("Teacher")) {
			/**
			 * // Teachers Display Data ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from teachers");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|" + rs.getInt(4)
							+ "|" + rs.getInt(5));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfDisplay.equalsIgnoreCase("Cource")) {
			/**
			 * // Courses Display Data ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from cources");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|" + rs.getInt(4)
							+ "|" + rs.getString(5));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfDisplay.equalsIgnoreCase("Department")) {
			/**
			 * // Department Display Data ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from departments");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|" + rs.getInt(4)
							+ "|" + rs.getDate(5));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfDisplay.equalsIgnoreCase("Admin")) {
			/**
			 * // Admit Display Data ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from admin");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|" + rs.getInt(4)
							+ "|" + rs.getDate(5));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfDisplay.equalsIgnoreCase("Liberary")) {
			/**
			 * // Library Display Data ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from liberary");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|" + rs.getInt(4)
							+ "|" + rs.getString(5) + "|" + rs.getInt(6));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfDisplay.equalsIgnoreCase("Sport")) {
			/**
			 * // Sports Display Data ########
			 */
			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement("Select * from sports");
				ResultSet rs = pst.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|" + rs.getInt(4)
							+ "|" + rs.getString(5) + "|" + rs.getInt(6));
				}
				menuMethod.menu();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		}
	}
}
