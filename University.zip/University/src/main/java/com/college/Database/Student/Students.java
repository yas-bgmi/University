package com.college.Database.Student;

/**
 * This file is an Students main class which has stored getter & setter for
 * Students operations;;;;
 */

public class Students {

	private int id;
	private String name;
	private String address;
	private int marks;
	private int status;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public Students() {

	}

	public Students(int id, String name, String address, int marks, int status) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.marks = marks;
		this.status = status;
	}

	@Override
	public String toString() {
		return "Students [id=" + id + ", name=" + name + ", address=" + address + ", marks=" + marks + ", status="
				+ status + ", getId()=" + getId() + ", getName()=" + getName() + ", getAddress()=" + getAddress()
				+ ", getMarks()=" + getMarks() + ", getStatus()=" + getStatus() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	public class studentsmenu {

	}

}
