package com.college.Database.Cource;

/**
 * This file is an Course main class which has stored getter & setter for Course
 * operations;;;;
 */

public class Cources {

	private int id;
	private String name;
	private String streamName;
	private int subId;
	private String collegeName;
	private int status;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStreamName() {
		return streamName;
	}

	public void setStreamName(String streamName) {
		this.streamName = streamName;
	}

	public int getSubId() {
		return subId;
	}

	public void setSubId(int subId) {
		this.subId = subId;
	}

	public String getCollegeName() {
		return collegeName;
	}

	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Cources [id=" + id + ", name=" + name + ", streamName=" + streamName + ", subId=" + subId
				+ ", collegeName=" + collegeName + ", status=" + status + ", getId()=" + getId() + ", getName()="
				+ getName() + ", getStreamName()=" + getStreamName() + ", getSubId()=" + getSubId()
				+ ", getCollegeName()=" + getCollegeName() + ", getStatus()=" + getStatus() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
