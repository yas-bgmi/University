package com.college.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

import com.college.Database.Admins.Admin;
import com.college.Database.Cource.Cources;
import com.college.Database.Dbconnection.DbConnection;
import com.college.Database.Departments.Department;
import com.college.Database.Library.Liberary;
import com.college.Database.Sport.Sports;
import com.college.Database.Student.Students;
import com.college.Database.Teacher.Teachers;

/**
 * This file is used for Inserting Data in DataBase;;;;;
 */

public class InsertDataIntoDatabase {
	MenuMethod menuMethod = new MenuMethod();
	Scanner sc = new Scanner(System.in);

	public void insertData(String typeOfInsert) {
		if (typeOfInsert.equalsIgnoreCase("Student")) {
			/**
			 * // Students Inserting Data ########
			 */
			Students std = new Students();
			

			System.out.println("Enter your Name here:");
			String name = sc.next();
			std.setName(name);

			System.out.println("Enter your Address here:");
			String address = sc.next();
			std.setAddress(address);

			System.out.println("Enter your Marks here:");
			int marks = sc.nextInt();
			std.setMarks(marks);

			System.out.println("Choose your status 1 or 0");
			int Status = sc.nextInt();
			std.setStatus(Status);

			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con
						.prepareStatement("Insert into students(name,address,marks,Status)values(?,?,?,?)");
				pst.setString(2, std.getName());
				pst.setString(3, std.getAddress());
				pst.setInt(4, std.getMarks());
				pst.setInt(5, std.getStatus());
				System.out.println("query submitted"+ pst);

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Inserted");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}
		} else if (typeOfInsert.equalsIgnoreCase("Teacher")) {
			/**
			 * // Teachers Inserting Data ########
			 */
			Teachers teacher = new Teachers();
			System.out.println("Enter your id here:");
			int id = sc.nextInt();
			teacher.setId(id);

			System.out.println("Enter your Name here:");
			String name = sc.next();
			teacher.setName(name);

			System.out.println("Enter your Teacher Name here:");
			String teacherName = sc.next();
			teacher.setTeacherName(teacherName);

			System.out.println("Enter your Std Id here:");
			int StdId = sc.nextInt();
			teacher.setStdId(StdId);

			System.out.println("Enter your Status Id here:");
			int Status = sc.nextInt();
			teacher.setStatus(Status);

			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con
						.prepareStatement("Insert into teachers(name,Teacher_name,Std_id,Status)values(?,?,?,?)");
				pst.setString(2, teacher.getName());
				pst.setString(3, teacher.getTeacherName());
				pst.setInt(4, teacher.getStdId());
				pst.setInt(5, teacher.getStatus());
                System.out.println("query submitted"+ pst);
				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Inserted");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}
		} else if (typeOfInsert.equalsIgnoreCase("Cource")) {
			/**
			 * // Courses Inserting Data ########
			 */
			Cources cources = new Cources();
			System.out.println("Enter your id here:");
			int id = sc.nextInt();
			cources.setId(id);

			System.out.println("Enter your Name here:");
			String name = sc.next();
			cources.setName(name);

			System.out.println("Enter your Stream Name here:");
			String StreamName = sc.next();
			cources.setStreamName(StreamName);

			System.out.println("Enter your Sub Id here:");
			int SubId = sc.nextInt();
			cources.setSubId(SubId);

			System.out.println("Enter your College Name here:");
			String CollegeName = sc.next();
			cources.setCollegeName(CollegeName);

			System.out.println("Enter your Status here:");
			int Status = sc.nextInt();
			cources.setStatus(Status);

			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement(
						"Insert into Cources(id,name,Stream_Name,Sub_id,College_name,Status)values(?,?,?,?,?,?)");
				pst.setInt(1, cources.getId());
				pst.setString(2, cources.getName());
				pst.setString(3, cources.getStreamName());
				pst.setInt(4, cources.getSubId());
				pst.setString(5, cources.getCollegeName());
				pst.setInt(6, cources.getStatus());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Inserted");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}
		} else if (typeOfInsert.equalsIgnoreCase("Department")) {
			/**
			 * // Department Inserting Data ########
			 */
			Department department = new Department();
			System.out.println("Enter your id here:");
			int id = sc.nextInt();
			department.setId(id);

			System.out.println("Enter your Name here:");
			String name = sc.next();
			department.setName(name);

			System.out.println("Enter your Department Name here:");
			String DepartmentName = sc.next();
			department.setDepartmentName(DepartmentName);

			System.out.println("Enter your Department Id here:");
			int DepartmentId = sc.nextInt();
			department.setDepartmentId(DepartmentId);

			System.out.println("Enter your Addmission Date here (yyyy-mm-dd):");
			String AddmissionDate = sc.next();
			department.setAddmissionDate(AddmissionDate);

			System.out.println("Enter your Status here:");
			int Status = sc.nextInt();
			department.setStatus(Status);

			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement(
						"Insert into Department(id,name,department_name,department_id,Addmission_date, Status)values(?,?,?,?,?,?)");
				pst.setInt(1, department.getId());
				pst.setString(2, department.getName());
				pst.setString(3, department.getDepartmentName());
				pst.setInt(4, department.getDepartmentId());
				pst.setString(5, department.getAddmissionDate());
				pst.setInt(6, department.getStatus());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Inserted");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}
		} else if (typeOfInsert.equalsIgnoreCase("Admin")) {
			/**
			 * // Admin Inserting Data ########
			 */
			Admin admin = new Admin();
			System.out.println("Enter your id here:");
			int id = sc.nextInt();
			admin.setId(id);

			System.out.println("Enter your Name here:");
			String name = sc.next();
			admin.setName(name);

			System.out.println("Enter your Stream Name here:");
			String StreamName = sc.next();
			admin.setStreamName(StreamName);

			System.out.println("Enter your Addmission Id here:");
			int AddmissionId = sc.nextInt();
			admin.setAddmissionId(AddmissionId);

			System.out.println("Enter your Addmission Date here (yyyy-mm-dd):");
			String AddmissionDate = sc.next();
			admin.setAddmissionDate(AddmissionDate);

			System.out.println("Enter your Status here:");
			int Status = sc.nextInt();
			admin.setStatus(Status);

			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement(
						"Insert into admin(id,name,Stream_name,Addmission_id,Addmission_date,Status)values(?,?,?,?,?,?)");
				pst.setInt(1, admin.getId());
				pst.setString(2, admin.getName());
				pst.setString(3, admin.getStreamName());
				pst.setInt(4, admin.getAddmissionId());
				pst.setString(5, admin.getAddmissionDate());
				pst.setInt(6, admin.getStatus());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Inserted");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfInsert.equalsIgnoreCase("Liberary")) {
			/**
			 * // Library Inserting Data ########
			 */
			Liberary liberary = new Liberary();
			System.out.println("Enter your id here:");
			int id = sc.nextInt();
			liberary.setId(id);

			System.out.println("Enter your Name here:");
			String name = sc.next();
			liberary.setName(name);

			System.out.println("Enter your Stream Name here:");
			String StreamName = sc.next();
			liberary.setStreamName(StreamName);

			System.out.println("Enter your Liberary Id here:");
			int LibId = sc.nextInt();
			liberary.setLibId(LibId);

			System.out.println("Enter your College Name here:");
			String CollegeName = sc.next();
			liberary.setCollegeName(CollegeName);

			System.out.println("Enter your Status here:");
			int Status = sc.nextInt();
			liberary.setStatus(Status);

			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement(
						"Insert into liberary(id,name,Stream_name,Lib_id,College_name, Status)values(?,?,?,?,?,?)");
				pst.setInt(1, liberary.getId());
				pst.setString(2, liberary.getName());
				pst.setString(3, liberary.getStreamName());
				pst.setInt(4, liberary.getLibId());
				pst.setString(5, liberary.getCollegeName());
				pst.setInt(6, liberary.getStatus());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Inserted");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfInsert.equalsIgnoreCase("Sport")) {
			/**
			 * // Sports Inserting Data ########
			 */
			Sports sport = new Sports();
			System.out.println("Enter your id here:");
			int id = sc.nextInt();
			sport.setId(id);

			System.out.println("Enter your Name here:");
			String name = sc.next();
			sport.setName(name);

			System.out.println("Enter your Stream Name here:");
			String StreamName = sc.next();
			sport.setStreamName(StreamName);

			System.out.println("Enter your Sport Id here:");
			int SportsId = sc.nextInt();
			sport.setSportsId(SportsId);

			System.out.println("Enter your Sport Name here:");
			String SportsName = sc.next();
			sport.setSportsName(SportsName);

			System.out.println("Enter your Status here:");
			int Status = sc.nextInt();
			sport.setStatus(Status);

			try {
				Connection con = DbConnection.getConnect();
				PreparedStatement pst = con.prepareStatement(
						"Insert into Sports(id,name,Stream_name,Sports_id,Sports_name, Status)values(?,?,?,?,?,?)");
				pst.setInt(1, sport.getId());
				pst.setString(2, sport.getName());
				pst.setString(3, sport.getStreamName());
				pst.setInt(4, sport.getSportsId());
				pst.setString(5, sport.getSportsName());
				pst.setInt(6, sport.getStatus());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Inserted");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		}
	}
}
