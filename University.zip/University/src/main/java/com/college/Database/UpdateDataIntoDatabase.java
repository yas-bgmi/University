package com.college.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

import com.college.Database.Admins.Admin;
import com.college.Database.Cource.Cources;
import com.college.Database.Dbconnection.DbConnection;
import com.college.Database.Departments.Department;
import com.college.Database.Library.Liberary;
import com.college.Database.Sport.Sports;
import com.college.Database.Student.Students;
import com.college.Database.Teacher.Teachers;

/**
 * This file is used for Updating existing Data in DataBase;;;;;
 */

public class UpdateDataIntoDatabase {
	MenuMethod menuMethod = new MenuMethod();
	Scanner sc = new Scanner(System.in);

	public void updateData(String typeOfUpdate) {
		if (typeOfUpdate.equalsIgnoreCase("Student")) {
			/**
			 * // Students Updating Data ########
			 */
			Students std = new Students();
			System.out.println("Enter Name here:");
			String name = sc.next();
			std.setName(name);

			System.out.println("Enter Address here:");
			String address = sc.next();
			std.setAddress(address);

			System.out.println("Enter Marks here:");
			int marks = sc.nextInt();
			std.setMarks(marks);

			System.out.println("Enter Status here:");
			int status = sc.nextInt();
			std.setStatus(status);

			System.out.println("Enter id here:");
			int id = sc.nextInt();
			std.setId(id);
			try {
				Connection con = DbConnection.getConnect();
				String str = "update students set name=?, address=?, marks=?, Status=? where id=?";
				PreparedStatement pst = con.prepareStatement(str);

				pst.setString(1, std.getName());
				pst.setString(2, std.getAddress());
				pst.setInt(3, std.getMarks());
				pst.setInt(4, std.getStatus());
				pst.setInt(5, std.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Updated");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}
		} else if (typeOfUpdate.equalsIgnoreCase("Teacher")) {
			/**
			 * // Teachers Updating Data ########
			 */
			Teachers teacher = new Teachers();
			System.out.println("Enter Name here:");
			String name = sc.next();
			teacher.setName(name);

			System.out.println("Enter Address here:");
			String teachername = sc.next();
			teacher.setTeacherName(teachername);

			System.out.println("Enter Marks here:");
			int StdId = sc.nextInt();
			teacher.setStdId(StdId);

			System.out.println("Enter Status here:");
			int status = sc.nextInt();
			teacher.setStatus(status);

			System.out.println("Enter id here:");
			int id = sc.nextInt();
			teacher.setId(id);
			try {
				Connection con = DbConnection.getConnect();
				String str = "update teachers set name=?, Teacher_name=?, Std_id=?, Status=? where id=?";
				PreparedStatement pst = con.prepareStatement(str);

				pst.setString(1, teacher.getName());
				pst.setString(2, teacher.getTeacherName());
				pst.setInt(3, teacher.getStdId());
				pst.setInt(4, teacher.getStatus());
				pst.setInt(5, teacher.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Updated");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}
		} else if (typeOfUpdate.equalsIgnoreCase("Cource")) {
			/**
			 * // Courses Updating Data ########
			 */
			Cources cources = new Cources();
			System.out.println("Enter Name here:");
			String name = sc.next();
			cources.setName(name);

			System.out.println("Enter Stream Name here:");
			String Streamname = sc.next();
			cources.setStreamName(Streamname);

			System.out.println("Enter Sub Id here:");
			int SubId = sc.nextInt();
			cources.setSubId(SubId);

			System.out.println("Enter College Name here");
			String CollegeName = sc.next();
			cources.setCollegeName(CollegeName);

			System.out.println("Enter Status here:");
			int Status = sc.nextInt();
			cources.setStatus(Status);

			System.out.println("Enter id here:");
			int id = sc.nextInt();
			cources.setId(id);
			try {
				Connection con = DbConnection.getConnect();
				String str = "update Cources set name=?, Stream_Name=?, Sub_id=?, College_name=?, Status=? where id=?";
				PreparedStatement pst = con.prepareStatement(str);

				pst.setString(1, cources.getName());
				pst.setString(2, cources.getStreamName());
				pst.setInt(3, cources.getSubId());
				pst.setString(4, cources.getCollegeName());
				pst.setInt(5, cources.getStatus());
				pst.setInt(6, cources.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Updated");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfUpdate.equalsIgnoreCase("Department")) {
			/**
			 * // Department Updating Data ########
			 */
			Department department = new Department();
			System.out.println("Enter Name here:");
			String name = sc.next();
			department.setName(name);

			System.out.println("Enter Department Name here:");
			String DepartmentName = sc.next();
			department.setDepartmentName(DepartmentName);

			System.out.println("Enter Department Id here:");
			int DepartmentId = sc.nextInt();
			department.setDepartmentId(DepartmentId);

			System.out.println("Enter Addmission date here");
			String Addmissiondate = sc.next();
			department.setAddmissionDate(Addmissiondate);

			System.out.println("Enter Status here:");
			int Status = sc.nextInt();
			department.setStatus(Status);

			System.out.println("Enter id here:");
			int id = sc.nextInt();
			department.setId(id);
			try {
				Connection con = DbConnection.getConnect();
				String str = "update Department set name=?, department_name=?, department_id=?, Addmission_date=?, Status=?  where id=?";
				PreparedStatement pst = con.prepareStatement(str);

				pst.setString(1, department.getName());
				pst.setString(2, department.getDepartmentName());
				pst.setInt(3, department.getDepartmentId());
				pst.setString(4, department.getAddmissionDate());
				pst.setInt(5, department.getStatus());
				pst.setInt(6, department.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Updated");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfUpdate.equalsIgnoreCase("Admin")) {
			/**
			 * // Admin Updating Data ########
			 */
			Admin admin = new Admin();
			System.out.println("Enter Name here:");
			String name = sc.next();
			admin.setName(name);

			System.out.println("Enter Stream Name here:");
			String StreamName = sc.next();
			admin.setStreamName(StreamName);

			System.out.println("Enter Addmission Id here:");
			int AddmissionId = sc.nextInt();
			admin.setAddmissionId(AddmissionId);

			System.out.println("Enter Addmission date here");
			String Addmissiondate = sc.next();
			admin.setAddmissionDate(Addmissiondate);

			System.out.println("Enter Status here");
			int Status = sc.nextInt();
			admin.setStatus(Status);

			System.out.println("Enter id here:");
			int id = sc.nextInt();
			admin.setId(id);
			try {
				Connection con = DbConnection.getConnect();
				String str = "update admin set name=?, Stream_name=?, Addmission_id=?, Addmission_date=?, Status=? where id=?";
				PreparedStatement pst = con.prepareStatement(str);

				pst.setString(1, admin.getName());
				pst.setString(2, admin.getStreamName());
				pst.setInt(3, admin.getAddmissionId());
				pst.setString(4, admin.getAddmissionDate());
				pst.setInt(5, admin.getStatus());
				pst.setInt(6, admin.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Updated");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfUpdate.equalsIgnoreCase("Liberary")) {
			/**
			 * // Library Updating Data ########
			 */
			Liberary liberary = new Liberary();
			System.out.println("Enter Name here:");
			String name = sc.next();
			liberary.setName(name);

			System.out.println("Enter Stream Name here:");
			String StreamName = sc.next();
			liberary.setStreamName(StreamName);

			System.out.println("Enter Department Id here:");
			int LibId = sc.nextInt();
			liberary.setLibId(LibId);

			System.out.println("Enter Addmission date here");
			String CollegeName = sc.next();
			liberary.setCollegeName(CollegeName);

			System.out.println("Enter Status here:");
			int Status = sc.nextInt();
			liberary.setStatus(Status);

			System.out.println("Enter id here:");
			int id = sc.nextInt();
			liberary.setId(id);
			try {
				Connection con = DbConnection.getConnect();
				String str = "update liberary set name=?, Stream_name=?, Lib_id=?, College_name=?, Status=? where id=?";
				PreparedStatement pst = con.prepareStatement(str);

				pst.setString(1, liberary.getName());
				pst.setString(2, liberary.getStreamName());
				pst.setInt(3, liberary.getLibId());
				pst.setString(4, liberary.getCollegeName());
				pst.setInt(5, liberary.getStatus());
				pst.setInt(6, liberary.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Updated");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		} else if (typeOfUpdate.equalsIgnoreCase("Sport")) {
			/**
			 * // Sports Updating Data ########
			 */
			Sports sport = new Sports();
			System.out.println("Enter Name here:");
			String name = sc.next();
			sport.setName(name);

			System.out.println("Enter Stream Name here:");
			String StreamName = sc.next();
			sport.setStreamName(StreamName);

			System.out.println("Enter Sports Id here:");
			int SportsId = sc.nextInt();
			sport.setSportsId(SportsId);

			System.out.println("Enter Sports Name here");
			String SportsName = sc.next();
			sport.setSportsName(SportsName);

			System.out.println("Enter Status here:");
			int Status = sc.nextInt();
			sport.setStatus(Status);

			System.out.println("Enter id here:");
			int id = sc.nextInt();
			sport.setId(id);
			try {
				Connection con = DbConnection.getConnect();
				String str = "update Sports set name=?, Stream_name=?, Sports_id=?, Sports_name=? where id=?";
				PreparedStatement pst = con.prepareStatement(str);

				pst.setString(1, sport.getName());
				pst.setString(2, sport.getStreamName());
				pst.setInt(3, sport.getSportsId());
				pst.setString(4, sport.getSportsName());
				pst.setInt(5, sport.getStatus());
				pst.setInt(5, sport.getId());

				int x = pst.executeUpdate();
				pst.close();
				con.close();
				if (x == 1) {
					System.out.println("Record Updated");
					menuMethod.menu();
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error Found");
			}

		}
	}
}
