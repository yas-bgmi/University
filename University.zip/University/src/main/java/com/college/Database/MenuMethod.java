package com.college.Database;

import java.util.Scanner;

import com.college.Database.Admins.AdminMethod;
import com.college.Database.Cource.CourceMethod;
import com.college.Database.Departments.DepartmentMethod;
import com.college.Database.Library.LiberaryMethod;
import com.college.Database.Sport.SportsMethod;
import com.college.Database.Student.StudentMethod;
import com.college.Database.Teacher.TeacherMethod;

/**
 * This file is a Menu Method which is called in front of after enter your
 * name:: ;;;;
 */

public class MenuMethod {
	Scanner sc = new Scanner(System.in);

	public String menu() {
		System.out.println("Welcome to Gurugram University: ");
		System.out.println("1. Students\n" + "2. Teachers\n" + "3. Cources\n" + "4. Department\n" + "5. Admin\n"
				+ "6. Liberary\n" + "7. Sports\n" + "8. Exit");
		System.out.println("Enter Choice: ");
		int ch = sc.nextInt();
		if (ch == 1) {
			StudentMethod studentMethod = new StudentMethod();
			studentMethod.Student();
		} else if (ch == 2) {
			TeacherMethod teacherMethod = new TeacherMethod();
			teacherMethod.Teacher();
		} else if (ch == 3) {
			CourceMethod courceMethod = new CourceMethod();
			courceMethod.Cource();
		} else if (ch == 4) {
			DepartmentMethod departmentMethod = new DepartmentMethod();
			departmentMethod.Department();
		} else if (ch == 5) {
			AdminMethod adminMethod = new AdminMethod();
			adminMethod.Admin();
		} else if (ch == 6) {
			LiberaryMethod liberaryMethod = new LiberaryMethod();
			liberaryMethod.Liberary();
		} else if (ch == 7) {
			SportsMethod sportsMethod = new SportsMethod();
			sportsMethod.Sport();
		} else if (ch == 8) {
			System.out.println("Exit");
			System.exit(ch);
		} else {
			System.out.println("Wrong query");

			menu();
		}
		return null;
	}
}
